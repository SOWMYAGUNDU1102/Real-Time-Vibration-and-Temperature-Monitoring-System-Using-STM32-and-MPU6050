#include "mpu.h"
#include "main.h"
#include <stdio.h>

extern I2C_HandleTypeDef hi2c1;

void mpu6050_init(void)
{
    uint8_t check, data;

    // Check device
    HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, 0x75, 1, &check, 1, 100);
    if(check == 0x68) printf("MPU6050 Found!\n");
    else printf("MPU6050 ERROR!\n");

    // Wake up the sensor (exit sleep mode)
    data = 0;
    HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, PWR_MGMT_1, 1, &data, 1, 100);

    // Set accelerometer ±4g
    data = 0x08;
    HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, ACCEL_CONFIG, 1, &data, 1, 100);

    // Set gyroscope 500°/s
    data = 0x08;
    HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, GYRO_CONFIG, 1, &data, 1, 100);

    printf("MPU6050 Initialized\n");
}

void mpu6050_read(int16_t *ax, int16_t *ay, int16_t *az)
{
    uint8_t raw_data[6];

    HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, ACCEL_XOUT_H, 1, raw_data, 6, 100);

    *ax = (int16_t)(raw_data[0] << 8 | raw_data[1]);
    *ay = (int16_t)(raw_data[2] << 8 | raw_data[3]);
    *az = (int16_t)(raw_data[4] << 8 | raw_data[5]);

    memset(raw_data, 0, sizeof(raw_data));
}

uint8_t mpu6050_motion_detect(int16_t ax, int16_t ay, int16_t az)
{
    // Simple threshold based motion detection
    if (ax > 8600 || ay > 8000 || az > 8000 ||
        ax < -8000 || ay < -8000 || az < -8000)
    {
        return 1; // Motion detected
    }
    return 0; // No motion
}
