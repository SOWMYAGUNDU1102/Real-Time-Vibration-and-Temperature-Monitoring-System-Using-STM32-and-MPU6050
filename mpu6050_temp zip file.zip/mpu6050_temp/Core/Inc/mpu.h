#ifndef INC_MPU_H_
#define INC_MPU_H_

#include "stm32l4xx_hal.h"

#define MPU_ADDR  0x68 << 1

#define ACCEL_CONFIG     0x1C
#define GYRO_CONFIG      0x1B
#define PWR_MGMT_1       0x6B
#define ACCEL_XOUT_H     0x3B

void mpu6050_init(void);
void mpu6050_read(int16_t *ax, int16_t *ay, int16_t *az);
uint8_t mpu6050_motion_detect(int16_t ax, int16_t ay, int16_t az);

#endif
